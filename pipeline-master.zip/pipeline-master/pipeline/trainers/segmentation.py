from .base import TrainerBase


class TrainerSegmentation(TrainerBase):
    pass
