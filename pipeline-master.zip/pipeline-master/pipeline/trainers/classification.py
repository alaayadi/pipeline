from .base import TrainerBase


class TrainerClassification(TrainerBase):
    pass
