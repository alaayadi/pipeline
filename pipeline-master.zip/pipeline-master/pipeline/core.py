class PipelineError(Exception):
    pass
